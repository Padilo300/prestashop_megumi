/**
 * This is the entry point for specific javascript of theme
 */